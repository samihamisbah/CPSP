from django.shortcuts import render

def homePage(request):
    return render(request,"index.html")

def registerPage(request):
    return render(request,"register.html")

def aboutPage(request):
    return render(request,"about.html")

def servicePage(request):
    return render(request,"services.html")

def contactPage(request):
    return render(request,"contact.html")
