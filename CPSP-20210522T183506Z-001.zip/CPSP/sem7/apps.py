from django.apps import AppConfig


class Sem7Config(AppConfig):
    name = 'sem7'
