from django.urls import path
from . import views

urlpatterns =[
    path('', views.homePage, name='index'),
    path('register/', views.registerPage, name='register'),
    path('about/' ,views.aboutPage, name='about'),
    path('services/', views.servicePage, name ='services'),
    path('contact/',views.contactPage, name='contact'),

]
