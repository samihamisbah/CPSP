from django.apps import AppConfig


class DeptappConfig(AppConfig):
    name = 'deptapp'
