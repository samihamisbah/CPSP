from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model
#from app.models import fir
from . models import *
User=get_user_model()

class UserCreateForm(UserCreationForm):
    first_name=forms.CharField(max_length=100,label='Department Name')
    username=forms.CharField(max_length=100,label='Department Id',min_length=2)
    address = forms.CharField(max_length=100,label='Department Address')

    email = forms.EmailField(label='Department Email')

    class Meta:
        model = User
        fields = ('username', 'first_name' , 'address','email','password1','password2' )
