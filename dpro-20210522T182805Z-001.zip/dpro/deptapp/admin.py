from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from . forms import UserCreateForm
from django.contrib.auth import get_user_model

User=get_user_model()
# Register your models here.
class UserAdmin(UserAdmin):
    add_form = UserCreateForm
    form = UserCreateForm
    model = User
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('first_name', 'username', 'password1', 'password2','address','email','is_department'),
        }),
    )

admin.site.register(User, UserAdmin)