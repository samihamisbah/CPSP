from django.urls import path
from . import views
from django.contrib.auth import views as v

urlpatterns = [
    path('', views.homepage, name='index'),
    path('dashboard', views.dashboard, name='dashboard'),
    path('tabs', views.tabsPage, name='tabs'),
    path('widget', views.widgetPage, name='widget'),
    path('login', views.loginpage, name='login'),
    path('logout', views.logout_dept, name='logout'),
    path('table', views.tablePage, name='table'),
    path('typography', views.typographyPage, name='graph'),
    path('sign', views.singupPage, name='sign'),
    path('button', views.buttonPage, name='buttons'),
    path('chart', views.chartPage, name='chart'),
    path('compose', views.composePage, name='compose'),
    path('forms', views.formPage, name='forms'),
    path('inbox', views.inboxPage, name='inbox'),
    path('map', views.mapPage, name='map'),
    path('media', views.mediaPage, name='media'),
    path('project', views.projectPage, name='project'),
    path('profile', views.profilePage, name='profile'),
    path('ribbon', views.ribbonPage, name='ribbon'),
    path('editor', views.editorPage, name='editor'),
    path('displayfir/<int:pk>', views.displayfir, name='displayfir'),
    path('displaymissperson/<int.pk>', views.displaymissperson, name='displaymissperson'),
    path('pending', views.pending_fir, name='pending'),
    path('accepted', views.accepted_fir, name='accepted'),
    path('rejected', views.rejected_fir, name='rejected'),
    path('validation', views.validationPage, name='validation'),

    path('password-chang/', v.PasswordChangeView.as_view(template_name='dept/password_change.html'), name='change_password'),

    path('password-change-done/', v.PasswordChangeDoneView.as_view(template_name='dept/password_change_done.html'),
         name='password_change_done'),

    path('password-reset/', v.PasswordResetView.as_view(template_name='dept/password_reset.html',
                                                        email_template_name='dept/password_reset_email.html',
                                                        subject_template_name='dept/password_reset_email_subject.txt'),
         name='password_reset'),
    path('password-reset-done/', v.PasswordResetDoneView.as_view(template_name='dept/password_reset_done.html'),
         name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>',
         v.PasswordResetConfirmView.as_view(template_name='dept/password_reset_confirm.html'),
         name='password_reset_confirm'),
    path('password-reset-complete/', v.PasswordResetCompleteView.as_view(template_name='dept/password_reset_complete.html'),
         name='password_reset_complete'),

]