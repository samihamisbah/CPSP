from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from app.models import fir
from app.models import *
from app.forms import *
from django.contrib.auth import get_user_model
User=get_user_model()


def homepage(request):
    if request.user.is_authenticated == False:
        return redirect(loginpage )

    if request.user.is_department == True and request.user.is_authenticated==True:
        data = User.objects.filter(is_citizen='1').count()
        print(data)
        data2 = fir.objects.filter(area='Katargam').count()
        print(data2)
        data3 = fir.objects.filter(status='pending').count()
        print(data3)
        return render(request, "dept/index.html", {'citizen':data, 'data2':data2, 'data3':data3})
    else:
        return redirect('home')

def dashboard(request):
    data = User.objects.filter(is_citizen='1').count()
    data1 = fir.objects.filter(area='Katargam').count()
    print(data)
    print(data1)
    return render(request, "dept/index.html", {'data1':data1, 'citizen':data})

def tabsPage(request):

        if request.method == 'POST':
            form = FIRForm(request.POST)

            if form.is_valid():
                form = form.save(commit=False)
                form.citizen = request.user
                form.status = 'pending'

                form.save()

                return redirect(homepage)
            else:
                form = FIRForm()
                return render(request, "dept/tabs.html", {'form': form})

        else:
            form = FIRForm()
            return render(request, "dept/tabs.html", {'form': form})

def widgetPage(request):
    data=fir.objects.filter(area=request.user.username)
    data1=missperson.objects.filter(missingarea=request.user.username)
    data2 = lostnfound.objects.filter(area=request.user.username)
    return render(request, "dept/widget.html",{'data':data,'data1':data1,'data2':data2})

def singupPage(request):
    return render(request, "dept/sign.html")

def loginpage(request):
    if request.method == "POST":
        uname = request.POST.get('uname')
        password = request.POST.get('password')
        user = authenticate(username=uname, password=password)
        #print(user.is_department)
        if user:
            print('hello')
            if  user.is_department== 1:
                print('hello')
                login(request, user)
                print('login successful')
                return redirect(homepage)
            else:
                return render(request, "dept/login.html", {'message': 'Invalid Department ID or Password'})

        else:
            return render(request, "dept/login.html", {'message': 'Invalid Department ID or Password'})

    else:
        return render(request, "dept/login.html")

def logout_dept(request):
    logout(request)
    return redirect(loginpage)

def typographyPage(request):
    return render(request, "dept/typography.html")

def buttonPage(request):
    return render(request, "dept/buttons.html")

def chartPage(request):
    return render(request, "dept/chart.html")

def composePage(request):
    return render(request, "dept/compose.html")

def formPage(request):
    if request.method == 'POST':
        pass
        form = LostnfoundForm(request.POST)

        if form.is_valid():
            obj = Report.objects.create()
            form = form.save(commit=False)
            form.citizen = request.user
            form.status = 'pending'
            form.report = obj
            form.save()

            return redirect(homepage)
        else:
            form = LostnfoundForm()
            return render(request, "dept/forms.html", {'form': form})

    else:
        form = LostnfoundForm()
        return render(request, "dept/forms.html", {'form': form})

def tablePage(request):
    if request.method == 'POST':
        pass
        form = LostnfoundForm(request.POST)

        if form.is_valid():
            obj = Report.objects.create()
            form = form.save(commit=False)
            form.citizen = request.user
            form.status = 'pending'
            form.report = obj
            form.save()

            return redirect(homepage)
        else:
            form = LostnfoundForm()
            return render(request, "dept/table.html", {'form': form})

    else:
        form = LostnfoundForm()
        return render(request, "dept/table.html", {'form': form})

def validationPage(request):
    if request.method == 'POST':
        form=Missperson(request.POST)

        if form.is_valid():
            obj=Report.objects.create()
            form.citizen = request.user
            form.status = 'pending'
            form.report = obj
            form = form.save(commit=False)

            form.save()

            return redirect(homePage)
        else:
            form = Missperson()
            return render(request, "dept/validation.html", {'form': form})

    else:
        form = Missperson()
        return render(request, "dept/validation.html", {'form': form})

def inboxPage(request):
    return render(request, "dept/inbox.html")

def mapPage(request):
    return render(request, "dept/map.html")

def mediaPage(request):
    return render(request, "dept/media.html")

def projectPage(request):
    return render(request, "dept/project.html")

def profilePage(request):
    return render(request, "dept/profile.html")

def ribbonPage(request):
    return render(request, "dept/ribbon.html")

def editorPage(request):
    return render(request, "dept/editor.html")

def displayfir(request,pk):
    if request.method!='POST':
        data = fir.objects.get(pk=pk)
        return render(request, "dept/detailfir.html",{'data':data})
    else:
        remark=request.POST.get('remark')
        status=request.POST.get('hidden')
        if status=='accept':
            data = fir.objects.get(pk=pk)
            data.status='Accept'
            r=Report.objects.get(id=data.report.id)
            r.progress=5
            r.save()
            data.messege=remark

        else:
            data = fir.objects.get(pk=pk)
            data.status = 'Rejected'
            data.messege = remark
        data.save()
        return redirect(pending_fir)

def displaymissperson(request,pk):
    data = missperson.objects.get(pk=pk)
    return render(request, "dept/detailfir.html",{'data':data})

def pending_fir(request):
    data=fir.objects.filter(area=request.user.username, status='Pending')
    data1=missperson.objects.filter(missingarea=request.user.username,status='Pending')
    data2 = lostnfound.objects.filter(area=request.user.username,status='Pending')
    return render(request, "dept/calender.html",{'data':data,'data1':data1,'data2':data2})

def accepted_fir(request):
    data=fir.objects.filter(area=request.user.username, status='Accept')
    data1=missperson.objects.filter(missingarea=request.user.username,status='Accept')
    data2 = lostnfound.objects.filter(area=request.user.username,status='Accept')
    return render(request, "dept/calender.html",{'data':data,'data1':data1,'data2':data2})

def rejected_fir(request):
    data=fir.objects.filter(area=request.user.username, status='Rejected')
    data1=missperson.objects.filter(missingarea=request.user.username,status='Rejected')
    data2 = lostnfound.objects.filter(area=request.user.username,status='Rejected')
    return render(request, "dept/calender.html",{'data':data,'data1':data1,'data2':data2})


def check_lost(request):
    data=fir.objects.filter(area=request.user.username, status='pending')
    data1=missperson.objects.filter(missingarea=request.user.username,status='pending')
    data2 = lostnfound.objects.filter(area=request.user.username,status='pending')
    return render(request, "dept/calender.html",{'data':data,'data1':data1,'data2':data2})