from django import forms
from . models import fir
from . models import missperson
from . models import *


class DateTimeInput(forms.DateTimeInput):
    input_type = "datetime-local"


class FIRForm(forms.ModelForm):
    class Meta:
        # date = forms.DateTimeField(input_formats=['%d/%m/%Y %H:%M'])
        model = fir
        fields = ('category', 'description', 'evidence', 'witness', 'first_name', 'middle_name', 'last_name', 'street', 'area', 'image1', 'image2', 'image3', 'image4', 'image5', 'date', 'time')
        widgets = {'category':forms.Select(attrs={'placeholder':'Select the category of crime'}),
                   'description':forms.TextInput(attrs={'placeholder':'Enter the Description'}),
                   'evidence':forms.TextInput(attrs={'placeholder':'Enter the Evidence details which (if) you have'}),
                   'witness':forms.TextInput(attrs={'placeholder':'Enter the Details about any witness like any person details'}),
                   'first_name': forms.TextInput(attrs={'placeholder': 'Enter the Details about any witness`s First name'}),
                   'middle_name': forms.TextInput(attrs={'placeholder': 'Enter the Details about any witness`s Middle name'}),
                   'last_name': forms.TextInput(attrs={'placeholder': 'Enter the Details about any witness`s Last name'}),
                   'street': forms.TextInput(attrs={'placeholder':'Enter the street name or nearer street name'}),
                   'area': forms.Select(attrs={'empty_label':'Select the Area where the crime happened'}),
                   'date': forms.DateInput(attrs={'type': 'date'}),
                   'time': forms.TimeInput(attrs={'type': 'time'})
            }


class Missperson(forms.ModelForm):
    class Meta:

        model = missperson
        fields = ('firstname', 'lastname', 'age', 'height', 'image', 'missingarea','missingdate', 'discription')
        widgets = {'firstname': forms.TextInput(attrs={'placeholder': 'Enter the Details missing person`s First name'}),
                  'lastname': forms.TextInput(attrs={'placeholder': 'Enter the Details missing person`s Last name'}),
                   'age': forms.TextInput(attrs={'placeholder': 'Enter the age of missing person'}),
                   'height': forms.TextInput(attrs={'placeholder': 'Enter the approximate height of missing person'}),
                   'missingarea': forms.Select(attrs={'empty_label': "Select missing area where person seen last time"}),
                   'missingdate': forms.DateInput(attrs={'placeholder': 'Select the date since person is missing'}),
                   'discription': forms.TextInput(attrs={'placeholder': 'Enter the Details about missing person and othe details'})
            }

class LostnfoundForm(forms.ModelForm):
    class Meta:

        model = lostnfound
        fields = ('item', 'image', 'itemnumber', 'discription')
        widgets = {
            'item' : forms.Select(attrs={'placeholder':'Select the item '}),
            'itemnnumber' : forms.TextInput(attrs={'placeholder':'Enter the registration number of item '}),
            'discription' : forms.TextInput(attrs={'placeholder':'Enter the descrpition about the item'})
        }