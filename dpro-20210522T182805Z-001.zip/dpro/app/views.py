from django.shortcuts import render, redirect
from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate, login, logout
User = get_user_model()

from .forms import *

from googletrans import Translator


def homePage(request):
    if request.user.is_authenticated:

        return render(request, "home.html")
    else:
        return render(request, "index.html")

def registerPage(request):
    if request.method == 'POST':
        fname = request.POST.get('firstname')
        lname = request.POST.get('lastname')
        mobile = request.POST.get('mobile')
        gender = request.POST.get('gender')
        add = request.POST.get('address')
        uname = request.POST.get('adhar')
        email = request.POST.get('email')
        password = request.POST.get('password')
        dob = request.POST.get('dob')

        User.objects.create_user(gender=gender, dateOfBirth=dob, first_name=fname, last_name=lname, is_citizen=True,
                                 address=add, username=uname, email=email, password=password, mobile=mobile)
        return render(request, "index.html")
    else:
        return render(request, "register.html")

def aboutPage(request):
    return render(request, "about.html")

def contactPage(request):
    return render(request, "contact.html")

def servicePage(request):
    return render(request, "services.html")

def loginPage(request):
    if request.method == "POST":
        uname = request.POST.get('adhar')
        password = request.POST.get('password')
        user = authenticate(username=uname, password=password)
        print(user)
        if user:
            login(request, user)
            return redirect(homePage)
        else:
            return render(request, "login.html", {'message': 'Invalid Adhar number or Password'})
    return render(request, "login.html")

def HomePage(request):
    return render(request, "home.html")

def reportPage(request):
    return render(request, "report.html")

def firPage(request):
    if request.method == 'POST':
        form = FIRForm(request.POST)
        print(request.POST['area'])
        if form.is_valid():
            obj = Report.objects.create(citizen=request.user)
            form = form.save(commit=False)
            form.citizen = request.user
            form.status = 'pending'
            form.report=obj
            form.dpt=User.objects.get(first_name=request.POST['area'])
            form.save()

            return redirect(homePage)
        else:
            form = FIRForm()
            return render(request, "fir.html", {'form': form})

    else:
        form=FIRForm()
        return render(request, "fir.html", {'form' : form})

def logout_user(request):
    logout(request)
    return redirect(homePage)

def missPersonPage(request):
    if request.method == 'POST':
        form=Missperson(request.POST)

        if form.is_valid():
            obj=Report.objects.create()
            form.citizen = request.user
            form.status = 'pending'
            form.report = obj
            form = form.save(commit=False)

            form.save()

            return redirect(homePage)
        else:
            form = Missperson()
            return render(request, "missperson.html", {'form': form})

    else:
        form = Missperson()
        return render(request, "missperson.html", {'form': form})

def myrequestPage(request):
    firuser = fir.objects.filter(citizen=request.user)
    #return render(request, "myrequest.html", {'firuser': firuser})

    misspersonuser = missperson.objects.filter(citizen=request.user)
    lostnfounduser = lostnfound.objects.filter(citizen=request.user)
    return render(request, "myrequest.html", {'firuser':firuser, 'misspersonuser': misspersonuser, 'lostnfounduser':lostnfounduser})

def lostnfoundPage(request):
    if request.method == 'POST':
        pass
        form = LostnfoundForm(request.POST)

        if form.is_valid():
            obj=Report.objects.create()
            form = form.save(commit = False)
            form.citizen = request.user
            form.status = 'pending'
            form.report = obj
            form.save()

            return redirect(homePage)
        else:
            form = LostnfoundForm()
            return render(request, "lostnfound.html", {'form': form})

    else:
        form = LostnfoundForm()
        return render(request, "missperson.html", {'form': form})

def display_image(request):
    doc = lostnfound.object.all()

def formpage(request):
    return render(request, "formpage.html")

def licencepage(request):
    return render(request, "licencepage.html")

def myprofilePage(request):
    return render(request, "myprofile.html")

def findstationPage(request):
    return render(request, "findstation.html")

def findstation1Page(request):
    return render(request, "findstation1.html")

def wantedreportpage(request):
    return render(request, "wantedreport.html")

def myreqPage(request):
    if request.method=='POST':

        user_choice=request.POST.get('user_choice')
        print(user_choice)

        if user_choice == 'FIR':
            firuser = fir.objects.filter(citizen=request.user)
            return render(request, "myreq.html", {'firuser': firuser,'user_choice':'FIR'})
        elif user_choice == 'Missing':
            misspersonuser = missperson.objects.filter(citizen=request.user)
            return render(request, "myreq.html", {'misspersonuser': misspersonuser,'user_choice':'Missing'})
        else:
            lostnfounduser = lostnfound.objects.filter(citizen=request.user)
            return render(request, "myreq.html", {'lostnfounduser':lostnfounduser,'user_choice':'Lost'})

    else:
        return render(request, "myreq.html")



def dbpage(request):
    return render(request, "forms1.html")