from django.db import models
from googletrans import Translator

from django.contrib.auth.models import AbstractUser
from django.contrib.auth import get_user_model

from django.core.validators import MaxValueValidator
from datetime import datetime

class User(AbstractUser):
    is_department = models.BooleanField(default=False)
    is_citizen = models.BooleanField(default=False)
    address = models.TextField(default='surat')
    mobile = models.BigIntegerField(default=91)
    gender = models.CharField(max_length=5, default='male')
    adhar_image = models.ImageField(blank=True, null=True)
    dateOfBirth = models.DateField(blank=True, null=True)
    #adhar = models.IntegerField(blank=True, null=True)


class CrimeCategory(models.Model):
    category = models.CharField(max_length=30)

    def __str__(self):
        return self.category

class Report(models.Model):
    citizen = models.ForeignKey(get_user_model(), on_delete=models.CASCADE, related_name='reported_by',null=True)
    reporting_date=models.DateTimeField(auto_now=True)
    progress=models.IntegerField(default=0,null=True)



class fir(models.Model):
    areaChoice = (
        ('Adajan', 'Adajan'),
        ('Althan', 'Althan'),
        ('Ambanagar','Ambanagar'),
        ('Amroli','Amroli'),
        ('Anand Mahal Road','Anand Mahal Road'),
        ('Athwa','Athwa'),
        ('Athwa Gate', 'Athwa Gate'),
        ('Athwalines', 'Athwalines'),
        ('Bamroli Gam','Bamroli Gam'),
        ('Bardoli','Bardoli'),
        ('Begampura','Begampura'),
        ('Bhatar','Bhatar'),
        ('Bhestan', 'Bhestan'),
        ('Bhimrad', 'Bhimrad'),
        ('Canal Road', 'Canal Road'),
        ('Chowk Bazar', 'Chowk Bazar'),
        ('City Light', 'City Light'),
        ('Dabholi', 'Dabholi'),
        ('Dahin Nagar', 'Dahin Nagar'),
        ('Dindoli','Dindoli'),
        ('Dumas', 'Dumas'),
        ('Ghod Dod Road', 'Ghod Dod Road'),
        ('Godadara', 'Godadara'),
        ('Gopipura', 'Gopipura'),
        ('Gothan', 'Gothan'),
        ('Haripura', 'Haripura'),
        ('Hazira', 'Hazira'),
        ('Hazira - Adajan Road', 'Hazira - Adajan Road'),
        ('Ichchhapor', 'Ichchhapor'),
        ('Jahangir Pura', 'Jahangir Pura'),
        ('Jahangirabad', 'Jahangirabad'),
        ('Kadodara', 'Kadodara'),
        ('Kadodara Nagar', 'Kadodara Nagar'),
        ('Kamrej', 'Kamrej'),
        ('Kapodra', 'Kapodra'),
        ('Karamala', 'Karamala'),
        ('Katargam', 'Katargam'),
        ('Kharwar Nagar', 'Kharwar Nagar'),
        ('Khodiyar Nagar', 'Khodiyar Nagar'),
        ('Kim', 'Kim'),
        ('Kosamba', 'Kosamba'),
        ('Kumbharia Gam', 'Kumbharia Gam'),
        ('Laskana', 'Laskana'),
        ('Limla', 'Limla'),
        ('Magob', 'Magob'),
        ('Mahadev Nagar', 'Mahadev Nagar'),
        ('Mahidharpura', 'Mahidharpura'),
        ('Mahuva', 'Mahuva'),
        ('Majura Gate', 'Majura Gate'),
        ('Mandvi', 'Mandvi'),
        ('Masma', 'Masma'),
        ('Mosali', 'Mosali'),
        ('Mota', 'Mota'),
        ('Mota Varachha', 'Mota Varachha'),
        ('Mughal Sarai', 'Mughal Sarai'),
        ('Nana Varachha', 'Nana Varachha'),
        ('Nanavat', 'Nanavat'),
        ('Nanpura', 'Nanpura'),
        ('Narotam Nagar', 'Narotam Nagar'),
        ('Narthan', 'Narthan'),
        ('Navagam', 'Navagam'),
        ('Navsari Road', 'Navsari Road'),
        ('New City Light', 'New City Light'),
        ('New City Light Road', 'New City Light Road'),
        ('Olpad', 'Olpad'),
        ('Pal Gam', 'Pal Gam'),
        ('Palanpur Gam', 'Palanpur Gam'),
        ('Palanpur Jakatnaka', 'Palanpur Jakatnaka'),
        ('Palsana', 'Palsana'),
        ('Pandesara', 'Pandesara'),
        ('Pankaj Nagar', 'Pankaj Nagar'),
        ('Parvat Gam', 'Parvat Gam'),
        ('Parvat Patiya', 'Parvat Patiya'),
        ('Pasodara', 'Pasodara'),
        ('Patel Nagar','Patel Nagar'),
        ('Piplod', 'Piplod'),
        ('Punagam', 'Punagam'),
        ('Rander', 'Rander'),
        ('Rander Road', 'Rander Road'),
        ('Rustampura', 'Rustampura'),
        ('Sachin', 'Sachin'),
        ('Sagrampura', 'Sagrampura'),
        ('Salabatpura', 'Salabatpura'),
        ('Saiyadpura', 'Saiyadpura'),
        ('Saroli', 'Saroli'),
        ('Sayan', 'Sayan'),
        ('Shahpore', 'Shahpore'),
        ('Shakti Nagar', 'Shakti Nagar'),
        ('Sima Nagar', 'Sima Nagar'),
        ('Surat Dumas Road', 'Surat Dumas Road'),
        ('Tadwadi', 'Tadwadi'),
        ('Udhana', 'Udhana'),
        ('Umarwada', 'Umarwada'),
        ('Uttran', 'Uttran'),
        ('Varachha', 'Varachha'),
        ('Vareli', 'Vareli'),
        ('Vesu', 'Vesu'),
        ('Vedroad', 'Vedroad'),
        ('Vidhey Nagar', 'Vidhey Nagar'),
        ('VIP Road', 'VIP Road'),
        ('Vishal Nagar', 'Vishal Nagar'),
        ('Vishnu Nagar', 'Vishnu Nagar')

    )

    fir_status = (
        ('pending', 'pending'),
        ('accepted', 'accepted'),
        ('rejected', 'rejected'),
        ('completed', 'completed'),
    )
    citizen = models.ForeignKey(get_user_model(), on_delete=models.CASCADE, related_name='citizen')
    category = models.ForeignKey(CrimeCategory, on_delete=models.CASCADE)
    description = models.TextField()
    evidence = models.TextField(blank=True)
    witness = models.TextField(blank=True)
    first_name = models.CharField(max_length=50)
    middle_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    street = models.CharField(max_length=60)
    area = models.CharField(max_length=60, choices=areaChoice)
    image1 = models.ImageField(blank=True, null=True)
    image2 = models.ImageField(blank=True, null=True)
    image3 = models.ImageField(blank=True, null=True)
    image4 = models.ImageField(blank=True, null=True)
    image5 = models.ImageField(blank=True, null=True)
    date = models.DateField(blank=True, null=True)
    time = models.TimeField(blank=True, null=True)
    dpt = models.ForeignKey(get_user_model(), on_delete=models.SET_NULL, related_name='department', null=True)
    status = models.CharField(max_length=20, choices=fir_status)
    messege = models.CharField(max_length=500, blank=True)
    report=models.ForeignKey(Report,on_delete=models.CASCADE,null=True)

class missperson(models.Model):

    fir_status = (
        ('pending', 'pending'),
        ('accepted', 'accepted'),
        ('rejected', 'rejected'),
        ('completed', 'completed'),
    )
    areaChoice = (
        ('Adajan', 'Adajan'),
        ('Althan', 'Althan'),
        ('Ambanagar','Ambanagar'),
        ('Amroli','Amroli'),
        ('Anand Mahal Road','Anand Mahal Road'),
        ('Athwa','Athwa'),
        ('Athwa Gate', 'Athwa Gate'),
        ('Athwalines', 'Athwalines'),
        ('Bamroli Gam','Bamroli Gam'),
        ('Bardoli','Bardoli'),
        ('Begampura','Begampura'),
        ('Bhatar','Bhatar'),
        ('Bhestan', 'Bhestan'),
        ('Bhimrad', 'Bhimrad'),
        ('Canal Road', 'Canal Road'),
        ('Chowk Bazar', 'Chowk Bazar'),
        ('City Light', 'City Light'),
        ('Dabholi', 'Dabholi'),
        ('Dahin Nagar', 'Dahin Nagar'),
        ('Dindoli','Dindoli'),
        ('Dumas', 'Dumas'),
        ('Ghod Dod Road', 'Ghod Dod Road'),
        ('Godadara', 'Godadara'),
        ('Gopipura', 'Gopipura'),
        ('Gothan', 'Gothan'),
        ('Haripura', 'Haripura'),
        ('Hazira', 'Hazira'),
        ('Hazira - Adajan Road', 'Hazira - Adajan Road'),
        ('Ichchhapor', 'Ichchhapor'),
        ('Jahangir Pura', 'Jahangir Pura'),
        ('Jahangirabad', 'Jahangirabad'),
        ('Kadodara', 'Kadodara'),
        ('Kadodara Nagar', 'Kadodara Nagar'),
        ('Kamrej', 'Kamrej'),
        ('Kapodra', 'Kapodra'),
        ('Karamala', 'Karamala'),
        ('Katargam', 'Katargam'),
        ('Kharwar Nagar', 'Kharwar Nagar'),
        ('Khodiyar Nagar', 'Khodiyar Nagar'),
        ('Kim', 'Kim'),
        ('Kosamba', 'Kosamba'),
        ('Kumbharia Gam', 'Kumbharia Gam'),
        ('Laskana', 'Laskana'),
        ('Limla', 'Limla'),
        ('Magob', 'Magob'),
        ('Mahadev Nagar', 'Mahadev Nagar'),
        ('Mahidharpura', 'Mahidharpura'),
        ('Mahuva', 'Mahuva'),
        ('Majura Gate', 'Majura Gate'),
        ('Mandvi', 'Mandvi'),
        ('Masma', 'Masma'),
        ('Mosali', 'Mosali'),
        ('Mota', 'Mota'),
        ('Mota Varachha', 'Mota Varachha'),
        ('Mughal Sarai', 'Mughal Sarai'),
        ('Nana Varachha', 'Nana Varachha'),
        ('Nanavat', 'Nanavat'),
        ('Nanpura', 'Nanpura'),
        ('Narotam Nagar', 'Narotam Nagar'),
        ('Narthan', 'Narthan'),
        ('Navagam', 'Navagam'),
        ('Navsari Road', 'Navsari Road'),
        ('New City Light', 'New City Light'),
        ('New City Light Road', 'New City Light Road'),
        ('Olpad', 'Olpad'),
        ('Pal Gam', 'Pal Gam'),
        ('Palanpur Gam', 'Palanpur Gam'),
        ('Palanpur Jakatnaka', 'Palanpur Jakatnaka'),
        ('Palsana', 'Palsana'),
        ('Pandesara', 'Pandesara'),
        ('Pankaj Nagar', 'Pankaj Nagar'),
        ('Parvat Gam', 'Parvat Gam'),
        ('Parvat Patiya', 'Parvat Patiya'),
        ('Pasodara', 'Pasodara'),
        ('Patel Nagar','Patel Nagar'),
        ('Piplod', 'Piplod'),
        ('Punagam', 'Punagam'),
        ('Rander', 'Rander'),
        ('Rander Road', 'Rander Road'),
        ('Rustampura', 'Rustampura'),
        ('Sachin', 'Sachin'),
        ('Sagrampura', 'Sagrampura'),
        ('Salabatpura', 'Salabatpura'),
        ('Saiyadpura', 'Saiyadpura'),
        ('Saroli', 'Saroli'),
        ('Sayan', 'Sayan'),
        ('Shahpore', 'Shahpore'),
        ('Shakti Nagar', 'Shakti Nagar'),
        ('Sima Nagar', 'Sima Nagar'),
        ('Surat Dumas Road', 'Surat Dumas Road'),
        ('Tadwadi', 'Tadwadi'),
        ('Udhana', 'Udhana'),
        ('Umarwada', 'Umarwada'),
        ('Uttran', 'Uttran'),
        ('Varachha', 'Varachha'),
        ('Vareli', 'Vareli'),
        ('Vesu', 'Vesu'),
        ('Vedroad', 'Vedroad'),
        ('Vidhey Nagar', 'Vidhey Nagar'),
        ('VIP Road', 'VIP Road'),
        ('Vishal Nagar', 'Vishal Nagar'),
        ('Vishnu Nagar', 'Vishnu Nagar')

    )

    firstname = models.CharField(max_length=40)
    lastname = models.CharField(max_length=40)
    age = models.PositiveIntegerField(blank=True,null=True, validators=[MaxValueValidator(120)])
    height = models.IntegerField(blank=True,null=True)
    image = models.ImageField(blank=True, null=True)
    missingarea = models.CharField(max_length=60, choices=areaChoice)
    missingdate = models.DateField(blank=True, null=True)
    discription = models.TextField(blank=True, null=True)
    citizen = models.ForeignKey(get_user_model(), on_delete=models.CASCADE, related_name='mcitizen', null=True, blank=True)
    mdpt = models.ForeignKey(get_user_model(), on_delete=models.SET_NULL, related_name='mdepart', null=True)
    status = models.CharField(max_length=20, choices=fir_status, default='pending')
    messege = models.CharField(max_length=50, blank=True)
    report = models.ForeignKey(Report, on_delete=models.CASCADE,null=True)


class lostnfound(models.Model):

    thingchoice = (
        ('bike', 'bike'),
        ('car', 'car'),
        ('bicycle', 'bicycle'),
        ('document', 'document'),
        ('bag', 'bag'),

    )

    fir_status = (
        ('pending', 'pending'),
        ('accepted', 'accepted'),
        ('rejected', 'rejected'),
        ('completed', 'completed'),
    )

    areaChoice = (
        ('Adajan', 'Adajan'),
        ('Althan', 'Althan'),
        ('Ambanagar','Ambanagar'),
        ('Amroli','Amroli'),
        ('Anand Mahal Road','Anand Mahal Road'),
        ('Athwa','Athwa'),
        ('Athwa Gate', 'Athwa Gate'),
        ('Athwalines', 'Athwalines'),
        ('Bamroli Gam','Bamroli Gam'),
        ('Bardoli','Bardoli'),
        ('Begampura','Begampura'),
        ('Bhatar','Bhatar'),
        ('Bhestan', 'Bhestan'),
        ('Bhimrad', 'Bhimrad'),
        ('Canal Road', 'Canal Road'),
        ('Chowk Bazar', 'Chowk Bazar'),
        ('City Light', 'City Light'),
        ('Dabholi', 'Dabholi'),
        ('Dahin Nagar', 'Dahin Nagar'),
        ('Dindoli','Dindoli'),
        ('Dumas', 'Dumas'),
        ('Ghod Dod Road', 'Ghod Dod Road'),
        ('Godadara', 'Godadara'),
        ('Gopipura', 'Gopipura'),
        ('Gothan', 'Gothan'),
        ('Haripura', 'Haripura'),
        ('Hazira', 'Hazira'),
        ('Hazira - Adajan Road', 'Hazira - Adajan Road'),
        ('Ichchhapor', 'Ichchhapor'),
        ('Jahangir Pura', 'Jahangir Pura'),
        ('Jahangirabad', 'Jahangirabad'),
        ('Kadodara', 'Kadodara'),
        ('Kadodara Nagar', 'Kadodara Nagar'),
        ('Kamrej', 'Kamrej'),
        ('Kapodra', 'Kapodra'),
        ('Karamala', 'Karamala'),
        ('Katargam', 'Katargam'),
        ('Kharwar Nagar', 'Kharwar Nagar'),
        ('Khodiyar Nagar', 'Khodiyar Nagar'),
        ('Kim', 'Kim'),
        ('Kosamba', 'Kosamba'),
        ('Kumbharia Gam', 'Kumbharia Gam'),
        ('Laskana', 'Laskana'),
        ('Limla', 'Limla'),
        ('Magob', 'Magob'),
        ('Mahadev Nagar', 'Mahadev Nagar'),
        ('Mahidharpura', 'Mahidharpura'),
        ('Mahuva', 'Mahuva'),
        ('Majura Gate', 'Majura Gate'),
        ('Mandvi', 'Mandvi'),
        ('Masma', 'Masma'),
        ('Mosali', 'Mosali'),
        ('Mota', 'Mota'),
        ('Mota Varachha', 'Mota Varachha'),
        ('Mughal Sarai', 'Mughal Sarai'),
        ('Nana Varachha', 'Nana Varachha'),
        ('Nanavat', 'Nanavat'),
        ('Nanpura', 'Nanpura'),
        ('Narotam Nagar', 'Narotam Nagar'),
        ('Narthan', 'Narthan'),
        ('Navagam', 'Navagam'),
        ('Navsari Road', 'Navsari Road'),
        ('New City Light', 'New City Light'),
        ('New City Light Road', 'New City Light Road'),
        ('Olpad', 'Olpad'),
        ('Pal Gam', 'Pal Gam'),
        ('Palanpur Gam', 'Palanpur Gam'),
        ('Palanpur Jakatnaka', 'Palanpur Jakatnaka'),
        ('Palsana', 'Palsana'),
        ('Pandesara', 'Pandesara'),
        ('Pankaj Nagar', 'Pankaj Nagar'),
        ('Parvat Gam', 'Parvat Gam'),
        ('Parvat Patiya', 'Parvat Patiya'),
        ('Pasodara', 'Pasodara'),
        ('Patel Nagar','Patel Nagar'),
        ('Piplod', 'Piplod'),
        ('Punagam', 'Punagam'),
        ('Rander', 'Rander'),
        ('Rander Road', 'Rander Road'),
        ('Rustampura', 'Rustampura'),
        ('Sachin', 'Sachin'),
        ('Sagrampura', 'Sagrampura'),
        ('Salabatpura', 'Salabatpura'),
        ('Saiyadpura', 'Saiyadpura'),
        ('Saroli', 'Saroli'),
        ('Sayan', 'Sayan'),
        ('Shahpore', 'Shahpore'),
        ('Shakti Nagar', 'Shakti Nagar'),
        ('Sima Nagar', 'Sima Nagar'),
        ('Surat Dumas Road', 'Surat Dumas Road'),
        ('Tadwadi', 'Tadwadi'),
        ('Udhana', 'Udhana'),
        ('Umarwada', 'Umarwada'),
        ('Uttran', 'Uttran'),
        ('Varachha', 'Varachha'),
        ('Vareli', 'Vareli'),
        ('Vesu', 'Vesu'),
        ('Vedroad', 'Vedroad'),
        ('Vidhey Nagar', 'Vidhey Nagar'),
        ('VIP Road', 'VIP Road'),
        ('Vishal Nagar', 'Vishal Nagar'),
        ('Vishnu Nagar', 'Vishnu Nagar')

    )
    item = models.CharField(max_length=60, choices=thingchoice)
    image = models.ImageField(blank=True, null=True)
    itemnumber = models.CharField(null=True,max_length=15)
    discription = models.TextField(blank=True, null=True)
    area = models.CharField(max_length=60, choices=areaChoice, null=True)
    status = models.CharField(max_length=20, choices=fir_status, default='pending')
    report = models.ForeignKey(Report, on_delete=models.CASCADE,null=True)
    citizen = models.ForeignKey(get_user_model(), on_delete=models.CASCADE, related_name='lcitizen', null=True, blank=True)


