from django.urls import path
from . import views
from googletrans import Translator

urlpatterns =[
    path('', views.homePage, name='index'),
    path('register', views.registerPage, name='register'),
    path('about', views.aboutPage, name='about'),
    path('contact', views.contactPage, name='contact'),
    path('services', views.servicePage, name='services'),
    path('login', views.loginPage, name='login_user'),
    path('home', views.HomePage, name='home'),
    path('report', views.reportPage, name='report'),
    path('fir', views.firPage, name='fir'),
    path('logout', views.logout_user, name='logout_user'),
    path('missperson', views.missPersonPage, name='missperson'),
    path('myrequest', views.myrequestPage, name='myrequest'),
    path('lostnfound', views.lostnfoundPage, name='lostnfound'),
    path('formpage', views.formpage, name='formpage'),
    path('licencepage', views.licencepage, name='licencepage'),
    path('myprofile', views.myprofilePage, name='myprofile'),
    path('findstation', views.findstationPage, name='findstation'),
    path('findstation1', views.findstation1Page, name='findstation1'),
    path('wantedreport',views.wantedreportpage, name='wantedreport'),
    path('myreqpage',views.myreqPage, name='myreqpage'),
]
